# YT-DLP Server for Appwrite

A serverless YouTube audio extraction service built for Appwrite Functions, designed to replace unreliable third-party audio extraction services in ChordMiniApp.

## Features

- ✅ **Serverless**: Runs on Appwrite Functions
- ✅ **Reliable**: Uses yt-dlp directly, no third-party dependencies
- ✅ **Audio Extraction**: Extracts high-quality MP3 audio from YouTube videos
- ✅ **CORS Support**: Ready for web application integration
- ✅ **Error Handling**: Comprehensive error handling and logging
- ✅ **Validation**: URL validation and input sanitization

## API Usage

### Extract Audio from YouTube Video

**Endpoint**: `POST /functions/v1/execution`

**Request Body**:
```json
{
  "url": "https://www.youtube.com/watch?v=VIDEO_ID",
  "format": "bestaudio"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "videoId": "VIDEO_ID",
    "filename": "VIDEO_ID.mp3",
    "size": 1234567,
    "format": "mp3",
    "audio": "base64_encoded_audio_data"
  }
}
```

**Error Response**:
```json
{
  "success": false,
  "error": "Error message description"
}
```

## Deployment to Appwrite

### Prerequisites

1. **Appwrite CLI**: Install the Appwrite CLI
   ```bash
   npm install -g appwrite-cli
   ```

2. **Appwrite Account**: Create an account at [appwrite.io](https://appwrite.io)

3. **Project Setup**: Create a new project in Appwrite Console

### Deployment Steps

1. **Login to Appwrite**:
   ```bash
   appwrite login
   ```

2. **Initialize Project** (from the yt-dlp-server directory):
   ```bash
   cd yt-dlp-server
   appwrite init project
   ```

3. **Deploy Function**:
   ```bash
   appwrite deploy function
   ```

4. **Set Environment Variables** (if needed):
   ```bash
   appwrite functions updateVariable \
     --functionId=yt-dlp-audio-extractor \
     --key=NODE_ENV \
     --value=production
   ```

### Configuration

The `appwrite.json` file contains the function configuration:

- **Runtime**: Node.js 18.0
- **Timeout**: 300 seconds (5 minutes)
- **Memory**: Default Appwrite allocation
- **Execution**: Public access (any user can call)

### Local Testing

To test the function locally:

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Local Server** (requires Appwrite CLI):
   ```bash
   appwrite functions createExecution \
     --functionId=yt-dlp-audio-extractor \
     --data='{"url":"https://www.youtube.com/watch?v=jNQXAC9IVRw"}'
   ```

## Integration with ChordMiniApp

### Service Integration

Create a new service in your main application:

```typescript
// src/services/appwriteYtDlpService.ts
export class AppwriteYtDlpService {
  private readonly functionId = 'yt-dlp-audio-extractor';
  private readonly endpoint = 'https://[PROJECT-ID].appwrite.global';

  async extractAudio(videoUrl: string): Promise<ArrayBuffer> {
    const response = await fetch(`${this.endpoint}/functions/v1/execution`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: videoUrl,
        format: 'bestaudio'
      })
    });

    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error);
    }

    // Convert base64 to ArrayBuffer
    const binaryString = atob(result.data.audio);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    return bytes.buffer;
  }
}
```

### Replace Existing Service

Update your audio extraction pipeline to use the new Appwrite service:

```typescript
// In your existing service
const appwriteService = new AppwriteYtDlpService();

try {
  const audioBuffer = await appwriteService.extractAudio(videoUrl);
  // Process the audio buffer as needed
} catch (error) {
  console.error('Audio extraction failed:', error);
  // Fallback to other services if needed
}
```

## Monitoring and Logs

- **Function Logs**: Available in Appwrite Console → Functions → yt-dlp-audio-extractor → Logs
- **Execution History**: Track successful and failed executions
- **Performance Metrics**: Monitor execution time and resource usage

## Limitations

- **File Size**: Limited by Appwrite Function response size limits
- **Execution Time**: 5-minute timeout for long videos
- **Concurrent Executions**: Limited by Appwrite plan limits
- **Storage**: Temporary files are cleaned up after each execution

## Troubleshooting

### Common Issues

1. **yt-dlp Installation**: Ensure yt-dlp-wrap installs correctly in the serverless environment
2. **Memory Limits**: Large audio files may exceed memory limits
3. **Network Timeouts**: YouTube may block requests from certain IPs

### Error Codes

- `400`: Invalid request (missing URL, invalid YouTube URL)
- `500`: Server error (yt-dlp execution failed, file system errors)

## Security Considerations

- **Input Validation**: All URLs are validated before processing
- **Resource Limits**: Execution timeout prevents infinite loops
- **Temporary Files**: All temporary files are cleaned up
- **No Persistent Storage**: No user data is stored permanently
