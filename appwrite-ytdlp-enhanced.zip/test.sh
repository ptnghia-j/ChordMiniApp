#!/bin/bash

# YT-DLP Server Test Script
# Tests the deployed Appwrite function with a sample YouTube video

set -e

echo "🧪 Testing YT-DLP Server on Appwrite..."

# Test video URL (short video for quick testing)
TEST_URL="https://www.youtube.com/watch?v=jNQXAC9IVRw"
FUNCTION_ID="yt-dlp-audio-extractor"

echo "📹 Test video: $TEST_URL"
echo "🔧 Function ID: $FUNCTION_ID"

# Check if Appwrite CLI is available
if ! command -v appwrite &> /dev/null; then
    echo "❌ Appwrite CLI is not installed"
    exit 1
fi

# Check if user is logged in
if ! appwrite account get &> /dev/null; then
    echo "❌ Not logged in to Appwrite. Please run: appwrite login"
    exit 1
fi

echo "🚀 Creating function execution..."

# Create execution with test data
EXECUTION_RESULT=$(appwrite functions createExecution \
    --function-id="$FUNCTION_ID" \
    --body="{\"url\":\"$TEST_URL\",\"format\":\"bestaudio\"}" \
    2>&1)

echo "📊 Execution Result:"
echo "$EXECUTION_RESULT"

# Parse the result to check if it was successful
if echo "$EXECUTION_RESULT" | grep -q '"success":true'; then
    echo "✅ Test passed! Audio extraction successful."
    
    # Extract some info from the result
    if echo "$EXECUTION_RESULT" | grep -q '"videoId"'; then
        VIDEO_ID=$(echo "$EXECUTION_RESULT" | grep -o '"videoId":"[^"]*"' | cut -d'"' -f4)
        echo "📹 Video ID: $VIDEO_ID"
    fi
    
    if echo "$EXECUTION_RESULT" | grep -q '"size"'; then
        FILE_SIZE=$(echo "$EXECUTION_RESULT" | grep -o '"size":[0-9]*' | cut -d':' -f2)
        echo "📁 File size: $FILE_SIZE bytes"
    fi
    
    if echo "$EXECUTION_RESULT" | grep -q '"filename"'; then
        FILENAME=$(echo "$EXECUTION_RESULT" | grep -o '"filename":"[^"]*"' | cut -d'"' -f4)
        echo "📄 Filename: $FILENAME"
    fi
    
    echo ""
    echo "🎉 YT-DLP Server is working correctly!"
    
elif echo "$EXECUTION_RESULT" | grep -q '"success":false'; then
    echo "❌ Test failed! Audio extraction unsuccessful."
    
    # Try to extract error message
    if echo "$EXECUTION_RESULT" | grep -q '"error"'; then
        ERROR_MSG=$(echo "$EXECUTION_RESULT" | grep -o '"error":"[^"]*"' | cut -d'"' -f4)
        echo "💥 Error: $ERROR_MSG"
    fi
    
    echo ""
    echo "🔧 Troubleshooting tips:"
    echo "   1. Check function logs in Appwrite Console"
    echo "   2. Verify yt-dlp-wrap installation"
    echo "   3. Check function timeout settings"
    echo "   4. Ensure YouTube URL is accessible"
    
    exit 1
    
else
    echo "⚠️  Unexpected result format. Raw output:"
    echo "$EXECUTION_RESULT"
    echo ""
    echo "🔍 Please check the Appwrite Console for detailed logs."
    exit 1
fi

echo ""
echo "📋 Next steps:"
echo "   1. Update your ChordMiniApp to use this endpoint"
echo "   2. Replace the failing yt2mp3MagicService"
echo "   3. Monitor function performance in Appwrite Console"
echo ""
echo "🔗 Function URL pattern:"
echo "   POST https://[PROJECT-ID].appwrite.global/v1/functions/$FUNCTION_ID/executions"
