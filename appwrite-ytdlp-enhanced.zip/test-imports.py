"""
Test function to check what packages are available
"""

import json
import sys
import pkg_resources

def main(context):
    """
    Test function to list available packages
    """
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
    }

    try:
        # Get list of installed packages
        installed_packages = [d.project_name for d in pkg_resources.working_set]
        
        # Try to import yt-dlp
        yt_dlp_status = "not available"
        try:
            import yt_dlp
            yt_dlp_status = "available"
        except ImportError as e:
            yt_dlp_status = f"not available: {str(e)}"

        return context.res.json({
            'success': True,
            'data': {
                'python_version': sys.version,
                'installed_packages': sorted(installed_packages),
                'yt_dlp_status': yt_dlp_status,
                'package_count': len(installed_packages)
            }
        }, 200, headers)

    except Exception as e:
        return context.res.json({
            'success': False,
            'error': str(e)
        }, 500, headers)
