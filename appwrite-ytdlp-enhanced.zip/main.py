"""
Appwrite Function Entry Point - Python Version
YouTube audio extraction server using yt-dlp
"""

import json
import base64
import tempfile
import os
import re
from urllib.parse import urlparse, parse_qs
import yt_dlp


def main(context):
    """
    Main Appwrite Function handler
    """
    # Set CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Content-Type': 'application/json'
    }

    # Handle preflight OPTIONS request
    if context.req.method == 'OPTIONS':
        return context.res.json({'message': 'OK'}, 200, headers)

    try:
        context.log('Function started successfully')

        # Parse request body - handle both CLI and HTTP API formats
        try:
            # Debug logging
            context.log(f'Request body type: {type(context.req.body)}')
            context.log(f'Request body content: {context.req.body}')

            # Handle different request body formats
            if isinstance(context.req.body, str):
                # String body - parse as JSON
                body = json.loads(context.req.body)
            elif isinstance(context.req.body, dict):
                # Already a dictionary - use directly
                body = context.req.body
            else:
                # Try to convert to string and parse
                body_str = str(context.req.body)
                context.log(f'Converting body to string: {body_str}')
                body = json.loads(body_str)

            context.log(f'Parsed body: {body}')

        except (json.JSONDecodeError, TypeError, ValueError) as parse_error:
            context.error(f'Failed to parse request body: {parse_error}')
            context.error(f'Body type: {type(context.req.body)}')
            context.error(f'Body content: {context.req.body}')
            return context.res.json({
                'success': False,
                'error': f'Invalid JSON in request body: {str(parse_error)}'
            }, 400, headers)

        video_url = body.get('url')
        format_type = body.get('format', 'bestaudio')

        # Validate input
        if not video_url:
            return context.res.json({
                'success': False,
                'error': 'Missing required parameter: url'
            }, 400, headers)

        # Validate YouTube URL
        if not is_valid_youtube_url(video_url):
            return context.res.json({
                'success': False,
                'error': 'Invalid YouTube URL'
            }, 400, headers)

        context.log(f'Processing YouTube URL: {video_url}')

        # Extract video ID for filename
        video_id = extract_video_id(video_url)
        context.log(f'Extracting audio for video ID: {video_id}')

        # Create temporary directory for downloads
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = os.path.join(temp_dir, f'{video_id}.%(ext)s')

            # Configure yt-dlp options with enhanced bot detection bypass
            ydl_opts = {
                'format': 'bestaudio/best',
                'extractaudio': True,
                'audioformat': 'mp3',
                'audioquality': '0',  # Best quality
                'outtmpl': output_path,
                'noplaylist': True,
                'quiet': True,
                'no_warnings': True,

                # Enhanced headers to mimic real browser
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                },

                # Additional options to avoid bot detection
                'extractor_args': {
                    'youtube': {
                        'skip': ['dash', 'hls'],
                        'player_client': ['android', 'web'],
                        'player_skip': ['configs'],
                    }
                },

                # Network options to avoid detection
                'socket_timeout': 30,
                'retries': 3,
                'fragment_retries': 3,
                'skip_unavailable_fragments': True,

                # Use mobile client as fallback
                'extractor_retries': 3,
            }

            # Try multiple extraction strategies to bypass bot detection
            extraction_strategies = [
                ('primary', ydl_opts),
                ('mobile', {**ydl_opts, 'extractor_args': {'youtube': {'player_client': ['android']}}}),
                ('web_fallback', {**ydl_opts, 'extractor_args': {'youtube': {'player_client': ['web'], 'player_skip': ['js']}}}),
            ]

            video_title = 'Unknown'
            extraction_successful = False

            for strategy_name, opts in extraction_strategies:
                try:
                    context.log(f'Trying extraction strategy: {strategy_name}')

                    with yt_dlp.YoutubeDL(opts) as ydl:
                        # Get video info first
                        info = ydl.extract_info(video_url, download=False)
                        video_title = info.get('title', 'Unknown')
                        context.log(f'Video info retrieved with {strategy_name}: {video_title}')

                        # Download the audio
                        ydl.download([video_url])
                        context.log(f'yt-dlp extraction completed with {strategy_name}')
                        extraction_successful = True
                        break

                except Exception as strategy_error:
                    context.log(f'Strategy {strategy_name} failed: {str(strategy_error)}')
                    if 'Sign in to confirm' in str(strategy_error):
                        context.log(f'Bot detection triggered with {strategy_name}, trying next strategy...')
                        continue
                    elif strategy_name == extraction_strategies[-1][0]:  # Last strategy
                        # If this is the last strategy, re-raise the error
                        raise strategy_error
                    else:
                        continue

            if not extraction_successful:
                context.error('All extraction strategies failed')
                return context.res.json({
                    'success': False,
                    'error': 'Audio extraction failed: All strategies exhausted due to YouTube bot detection. Please try again later.'
                }, 500, headers)

            # Find the downloaded file
            files = os.listdir(temp_dir)
            audio_file = None

            # Look for audio files with various extensions
            audio_extensions = ['.mp3', '.webm', '.m4a', '.ogg', '.wav']
            for file in files:
                if file.startswith(video_id):
                    for ext in audio_extensions:
                        if file.endswith(ext):
                            audio_file = file
                            break
                    if audio_file:
                        break

            if not audio_file:
                context.error('No audio file found after extraction')
                context.log(f'Files in temp directory: {", ".join(files)}')
                return context.res.json({
                    'success': False,
                    'error': 'Audio extraction completed but no audio file was created'
                }, 500, headers)

            # Read the audio file
            audio_file_path = os.path.join(temp_dir, audio_file)
            with open(audio_file_path, 'rb') as f:
                audio_data = f.read()

            context.log(f'Audio file extracted successfully: {audio_file} ({len(audio_data)} bytes)')

            # Convert to base64
            base64_audio = base64.b64encode(audio_data).decode('utf-8')

            # Get actual file format
            file_extension = os.path.splitext(audio_file)[1][1:]  # Remove the dot

            return context.res.json({
                'success': True,
                'data': {
                    'videoId': video_id,
                    'title': video_title,
                    'filename': audio_file,
                    'size': len(audio_data),
                    'format': file_extension,
                    'audio': base64_audio
                }
            }, 200, headers)

    except Exception as general_error:
        context.error(f'General error in yt-dlp server: {general_error}')
        return context.res.json({
            'success': False,
            'error': f'Server error: {str(general_error)}'
        }, 500, headers)


def is_valid_youtube_url(url):
    """
    Validate if the URL is a valid YouTube URL
    """
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname.lower() if parsed.hostname else ''
        return (
            hostname == 'www.youtube.com' or
            hostname == 'youtube.com' or
            hostname == 'youtu.be' or
            hostname == 'm.youtube.com'
        )
    except:
        return False


def extract_video_id(url):
    """
    Extract video ID from YouTube URL
    """
    try:
        parsed = urlparse(url)

        if parsed.hostname == 'youtu.be':
            return parsed.path[1:]

        if 'youtube.com' in parsed.hostname:
            query_params = parse_qs(parsed.query)
            return query_params.get('v', [None])[0]

        return None
    except:
        return None
