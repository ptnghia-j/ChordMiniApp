#!/bin/bash

# Build script for Appwrite Python Function
echo "Installing Python dependencies..."

# Install yt-dlp
pip install yt-dlp

echo "Dependencies installed successfully!"
