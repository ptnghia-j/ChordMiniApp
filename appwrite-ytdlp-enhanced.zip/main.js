// Appwrite Function Entry Point
// This file imports and exports the main function from src/main.js

module.exports = require('./src/main.js');
