/**
 * Simple Appwrite Function Entry Point for Testing
 * This function tests basic functionality without yt-dlp
 */
module.exports = async ({ req, res, log, error }) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    return res.json({ message: 'OK' }, 200, headers);
  }

  try {
    log('Function started successfully');
    
    // Parse request body
    let body;
    try {
      body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    } catch (parseError) {
      error('Failed to parse request body:', parseError);
      return res.json({ 
        success: false, 
        error: 'Invalid JSON in request body' 
      }, 400, headers);
    }

    const { url: videoUrl, format = 'bestaudio' } = body;

    log(`Received request for URL: ${videoUrl}`);

    // For now, return a test response
    return res.json({
      success: true,
      message: 'YT-DLP Server is working!',
      data: {
        videoUrl,
        format,
        timestamp: new Date().toISOString(),
        status: 'Function deployed and running successfully'
      }
    }, 200, headers);

  } catch (generalError) {
    error('General error in yt-dlp server:', generalError);
    return res.json({ 
      success: false, 
      error: `Server error: ${generalError.message}` 
    }, 500, headers);
  }
};
