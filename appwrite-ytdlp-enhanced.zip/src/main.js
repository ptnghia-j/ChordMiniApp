const ytdl = require('@distube/ytdl-core');

/**
 * Appwrite Function Entry Point
 * This function handles YouTube audio extraction requests
 */
module.exports = async ({ req, res, log, error }) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    return res.json({ message: 'OK' }, 200, headers);
  }

  try {
    // Parse request body
    let body;
    try {
      body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    } catch (parseError) {
      error('Failed to parse request body:', parseError);
      return res.json({ 
        success: false, 
        error: 'Invalid JSON in request body' 
      }, 400, headers);
    }

    const { url: videoUrl, format = 'bestaudio' } = body;

    // Validate input
    if (!videoUrl) {
      return res.json({ 
        success: false, 
        error: 'Missing required parameter: url' 
      }, 400, headers);
    }

    // Validate YouTube URL
    if (!isValidYouTubeUrl(videoUrl)) {
      return res.json({ 
        success: false, 
        error: 'Invalid YouTube URL' 
      }, 400, headers);
    }

    log(`Processing YouTube URL: ${videoUrl}`);

    // Extract video ID for filename
    const videoId = extractVideoId(videoUrl);

    log(`Extracting audio for video ID: ${videoId}`);

    // Get video info first
    let videoInfo;
    try {
      videoInfo = await ytdl.getInfo(videoUrl);
      log(`Video info retrieved: ${videoInfo.videoDetails.title}`);
    } catch (infoError) {
      error('Failed to get video info:', infoError);
      return res.json({
        success: false,
        error: `Failed to get video information: ${infoError.message}`
      }, 500, headers);
    }

    // Create a readable stream for the audio
    const audioStream = ytdl(videoUrl, {
      quality: 'highestaudio',
      filter: 'audioonly'
    });

    // Collect audio data in chunks
    const audioChunks = [];

    try {
      await new Promise((resolve, reject) => {
        audioStream.on('data', (chunk) => {
          audioChunks.push(chunk);
        });

        audioStream.on('end', () => {
          log('Audio stream completed');
          resolve();
        });

        audioStream.on('error', (streamError) => {
          error('Audio stream error:', streamError);
          reject(streamError);
        });
      });
    } catch (streamError) {
      error('Audio extraction failed:', streamError);
      return res.json({
        success: false,
        error: `Audio extraction failed: ${streamError.message}`
      }, 500, headers);
    }

    // Combine all chunks into a single buffer
    const audioBuffer = Buffer.concat(audioChunks);

    log(`Audio extracted successfully: ${audioBuffer.length} bytes`);

    // Return the audio file as base64 encoded data
    const base64Audio = audioBuffer.toString('base64');

    return res.json({
      success: true,
      data: {
        videoId,
        title: videoInfo.videoDetails.title,
        filename: `${videoId}.webm`,
        size: audioBuffer.length,
        format: 'webm',
        audio: base64Audio
      }
    }, 200, headers);

  } catch (generalError) {
    error('General error in yt-dlp server:', generalError);
    return res.json({ 
      success: false, 
      error: `Server error: ${generalError.message}` 
    }, 500, headers);
  }
};

/**
 * Validate if the URL is a valid YouTube URL
 */
function isValidYouTubeUrl(url) {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    return (
      hostname === 'www.youtube.com' ||
      hostname === 'youtube.com' ||
      hostname === 'youtu.be' ||
      hostname === 'm.youtube.com'
    );
  } catch {
    return false;
  }
}

/**
 * Extract video ID from YouTube URL
 */
function extractVideoId(url) {
  try {
    const urlObj = new URL(url);
    
    if (urlObj.hostname === 'youtu.be') {
      return urlObj.pathname.slice(1);
    }
    
    if (urlObj.hostname.includes('youtube.com')) {
      return urlObj.searchParams.get('v') || 'unknown';
    }
    
    return 'unknown';
  } catch {
    return 'unknown';
  }
}
