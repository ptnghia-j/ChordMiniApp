#!/bin/bash

# Setup script for yt-dlp in Appwrite Functions
echo "Setting up yt-dlp..."

# Check if we're in Appwrite Functions environment
if [ -n "$APPWRITE_FUNCTION_ID" ]; then
    echo "Running in Appwrite Functions environment"

    # Try to install yt-dlp using pip3
    if command -v pip3 &> /dev/null; then
        echo "Installing yt-dlp with pip3..."
        pip3 install --user yt-dlp
    elif command -v pip &> /dev/null; then
        echo "Installing yt-dlp with pip..."
        pip install --user yt-dlp
    else
        echo "Warning: pip not found, trying alternative installation..."
        # Try to download yt-dlp binary directly
        curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /tmp/yt-dlp
        chmod +x /tmp/yt-dlp
        export PATH="/tmp:$PATH"
    fi
else
    echo "Running in local environment"
    pip3 install --user yt-dlp
fi

# Verify installation
if command -v yt-dlp &> /dev/null; then
    echo "yt-dlp version: $(yt-dlp --version)"
    echo "yt-dlp setup completed successfully!"
else
    echo "Warning: yt-dlp installation may have failed"
fi
