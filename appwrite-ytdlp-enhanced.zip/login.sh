#!/bin/bash

# Simple login script for Appwrite CLI
echo "🔐 Logging into Appwrite..."

# Set the correct endpoint and project
appwrite client --endpoint https://sfo.cloud.appwrite.io/v1 --project-id 68d48e41000a72457eb6

# Try to check if already logged in
if appwrite account get >/dev/null 2>&1; then
    echo "✅ Already logged in!"
    exit 0
fi

# Login with credentials
echo "📧 Email: ptnghia@csu.fullerton.edu"
echo "🔑 Password: [hidden]"

# Use expect to automate the login
expect << 'EOF'
spawn appwrite login
expect "What you like to do?"
send "\r"
expect "Enter your email"
send "ptnghia@csu.fullerton.edu\r"
expect "Enter your password"
send "Langxitrum2?\r"
expect eof
EOF

echo "✅ Login completed!"
