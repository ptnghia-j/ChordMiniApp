# YT-DLP Server Deployment Guide

This guide walks you through deploying the YT-DLP server to Appwrite Functions step by step.

## Prerequisites

### 1. Appwrite Account Setup
1. Go to [appwrite.io](https://appwrite.io) and create a free account
2. Create a new project in the Appwrite Console
3. Note down your **Project ID** (you'll need this later)

### 2. Install Appwrite CLI
```bash
npm install -g appwrite-cli
```

### 3. Login to Appwrite
```bash
appwrite login
```
Follow the prompts to authenticate with your Appwrite account.

## Deployment Steps

### Step 1: Navigate to YT-DLP Server Directory
```bash
cd yt-dlp-server
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Initialize Appwrite Project
```bash
appwrite init project
```
- Select your project from the list
- Choose the current directory as the project directory

### Step 4: Deploy the Function
```bash
./deploy.sh
```

Or manually:
```bash
appwrite deploy function
```

### Step 5: Verify Deployment
```bash
./test.sh
```

This will run a test extraction to ensure everything is working.

## Configuration

### Environment Variables

Add these to your main ChordMiniApp `.env.local`:

```env
# Appwrite Configuration
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your-project-id-here
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://your-project-id.appwrite.global
```

### Function Settings

The function is configured with:
- **Runtime**: Node.js 18.0
- **Timeout**: 300 seconds (5 minutes)
- **Memory**: Default Appwrite allocation
- **Execution**: Public (no authentication required)

## Integration with ChordMiniApp

### Step 1: Update Environment Variables
Add your Appwrite project ID to `.env.local`:
```env
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your-actual-project-id
```

### Step 2: Update Audio Service Priority
Modify your audio extraction service to prioritize the Appwrite service:

```typescript
// In your audio extraction service
import { appwriteYtDlpService } from '@/services/appwriteYtDlpService';

async function extractAudio(videoUrl: string): Promise<ArrayBuffer> {
  try {
    // Try Appwrite YT-DLP service first (most reliable)
    return await appwriteYtDlpService.extractAudio(videoUrl);
  } catch (error) {
    console.warn('Appwrite service failed, trying fallback:', error);
    // Fallback to other services...
  }
}
```

### Step 3: Test Integration
```typescript
// Test the service
const isWorking = await appwriteYtDlpService.testService();
console.log('Appwrite YT-DLP Service status:', isWorking);
```

## Monitoring and Maintenance

### Function Logs
1. Go to Appwrite Console
2. Navigate to Functions → yt-dlp-audio-extractor
3. Check the "Logs" tab for execution details

### Performance Monitoring
- Monitor execution time (should be under 60 seconds for most videos)
- Check success/failure rates
- Monitor memory usage

### Scaling Considerations
- **Concurrent Executions**: Limited by your Appwrite plan
- **Bandwidth**: Consider data transfer costs for large files
- **Rate Limiting**: YouTube may rate limit requests

## Troubleshooting

### Common Issues

#### 1. Function Timeout
**Problem**: Function times out after 5 minutes
**Solution**: 
- Use shorter videos for testing
- Consider increasing timeout in `appwrite.json`
- Check if yt-dlp is hanging on specific videos

#### 2. Memory Errors
**Problem**: Function runs out of memory
**Solution**:
- Process smaller audio files
- Optimize base64 encoding/decoding
- Consider streaming responses for large files

#### 3. yt-dlp Installation Issues
**Problem**: yt-dlp-wrap fails to install
**Solution**:
- Check Node.js version compatibility
- Verify package.json dependencies
- Try alternative yt-dlp packages

#### 4. Network Errors
**Problem**: Cannot reach YouTube or function fails
**Solution**:
- Check YouTube URL validity
- Verify network connectivity from Appwrite servers
- Consider IP-based restrictions

### Debug Commands

```bash
# Check function status
appwrite functions get --functionId=yt-dlp-audio-extractor

# View recent executions
appwrite functions listExecutions --functionId=yt-dlp-audio-extractor

# Test with specific video
appwrite functions createExecution \
  --functionId=yt-dlp-audio-extractor \
  --data='{"url":"https://www.youtube.com/watch?v=VIDEO_ID"}' \
  --async=false
```

## Cost Considerations

### Appwrite Pricing
- **Free Tier**: 750,000 function executions/month
- **Pro Tier**: $15/month for additional executions
- **Bandwidth**: Consider data transfer costs

### Optimization Tips
1. **Cache Results**: Cache extracted audio to avoid re-processing
2. **Batch Processing**: Process multiple requests efficiently
3. **Error Handling**: Fail fast on invalid requests
4. **Resource Cleanup**: Ensure temporary files are cleaned up

## Security

### Best Practices
1. **Input Validation**: Always validate YouTube URLs
2. **Rate Limiting**: Implement client-side rate limiting
3. **Error Messages**: Don't expose internal errors to clients
4. **Resource Limits**: Set appropriate timeouts and memory limits

### Access Control
The function is currently set to public access. To add authentication:

1. Update `appwrite.json`:
```json
{
  "execute": ["users"]
}
```

2. Pass authentication headers in requests:
```typescript
headers: {
  'X-Appwrite-Project': projectId,
  'Authorization': `Bearer ${userToken}`
}
```

## Next Steps

1. **Deploy to Production**: Follow this guide to deploy your function
2. **Update ChordMiniApp**: Integrate the new service
3. **Monitor Performance**: Keep an eye on function metrics
4. **Optimize**: Fine-tune based on usage patterns
5. **Scale**: Consider upgrading Appwrite plan if needed

## Support

- **Appwrite Documentation**: [appwrite.io/docs](https://appwrite.io/docs)
- **Function Logs**: Check Appwrite Console for detailed error messages
- **Community**: Appwrite Discord and GitHub discussions
