#!/bin/bash

# YT-DLP Server Deployment Script for Appwrite
# This script automates the deployment of the yt-dlp server to Appwrite Functions

set -e  # Exit on any error

echo "🚀 Starting YT-DLP Server deployment to Appwrite..."

# Check if Appwrite CLI is installed
if ! command -v appwrite &> /dev/null; then
    echo "❌ Appwrite CLI is not installed. Please install it first:"
    echo "   npm install -g appwrite-cli"
    exit 1
fi

# Check if we're in the correct directory
if [ ! -f "package.json" ] || [ ! -f "appwrite.json" ]; then
    echo "❌ Please run this script from the yt-dlp-server directory"
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if user is logged in to Appwrite
echo "🔐 Checking Appwrite authentication..."
if ! appwrite account get &> /dev/null; then
    echo "❌ Not logged in to Appwrite. Please login first:"
    echo "   appwrite login"
    exit 1
fi

# Get current project info
echo "📋 Getting project information..."
PROJECT_INFO=$(appwrite project get 2>/dev/null || echo "")

if [ -z "$PROJECT_INFO" ]; then
    echo "⚠️  No project initialized. Initializing project..."
    appwrite init project
else
    echo "✅ Project already initialized"
fi

# Deploy the function
echo "🚀 Deploying function to Appwrite..."
appwrite push

# Get function URL
echo "🔗 Getting function URL..."
FUNCTION_INFO=$(appwrite functions get --function-id=yt-dlp-audio-extractor 2>/dev/null || echo "")

if [ -n "$FUNCTION_INFO" ]; then
    echo "✅ Function deployed successfully!"
    echo ""
    echo "📋 Deployment Summary:"
    echo "   Function ID: yt-dlp-audio-extractor"
    echo "   Runtime: node-18.0"
    echo "   Timeout: 300 seconds"
    echo ""
    echo "🔗 Function Endpoint:"
    echo "   POST https://[PROJECT-ID].appwrite.global/v1/functions/yt-dlp-audio-extractor/executions"
    echo ""
    echo "📖 Usage Example:"
    echo '   curl -X POST https://[PROJECT-ID].appwrite.global/v1/functions/yt-dlp-audio-extractor/executions \'
    echo '     -H "Content-Type: application/json" \'
    echo '     -d '"'"'{"url":"https://www.youtube.com/watch?v=jNQXAC9IVRw","format":"bestaudio"}'"'"
    echo ""
    echo "🎉 Deployment completed successfully!"
else
    echo "❌ Function deployment may have failed. Please check the Appwrite console."
    exit 1
fi

# Optional: Run a test
read -p "🧪 Would you like to run a test extraction? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🧪 Running test extraction..."
    ./test.sh
fi

echo "✨ All done! Your YT-DLP server is ready to use."
